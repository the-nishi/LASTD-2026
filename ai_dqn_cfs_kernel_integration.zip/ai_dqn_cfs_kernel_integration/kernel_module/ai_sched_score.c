// ai_sched_score.c
// Prototype Linux kernel module exposing /proc/ai_scheduler_score
// Allows user-space DQN/LSTM controller to submit per-PID AI scheduling scores.
// NOTE: This is a research prototype skeleton; test only inside a VM.

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/sched/signal.h>
#include <linux/mutex.h>

#define PROC_NAME "ai_scheduler_score"
#define MAX_BUF 128

static DEFINE_MUTEX(ai_sched_lock);

struct ai_score_entry {
    pid_t pid;
    int score;
    int anomaly;
};

static struct ai_score_entry last_entry;

static ssize_t ai_sched_write(struct file *file, const char __user *buffer,
                              size_t count, loff_t *pos)
{
    char kbuf[MAX_BUF];
    pid_t pid;
    int score, anomaly;
    struct task_struct *task;

    if (count >= MAX_BUF)
        return -EINVAL;

    if (copy_from_user(kbuf, buffer, count))
        return -EFAULT;

    kbuf[count] = '\0';

    // Expected format: <pid> <score_0_100> <anomaly_0_100>
    if (sscanf(kbuf, "%d %d %d", &pid, &score, &anomaly) != 3)
        return -EINVAL;

    if (score < 0) score = 0;
    if (score > 100) score = 100;
    if (anomaly < 0) anomaly = 0;
    if (anomaly > 100) anomaly = 100;

    rcu_read_lock();
    task = pid_task(find_vpid(pid), PIDTYPE_PID);
    if (task) {
        // This skeleton stores only the latest submitted value.
        // For full integration, extend task_struct or maintain a pid->score map.
        mutex_lock(&ai_sched_lock);
        last_entry.pid = pid;
        last_entry.score = score;
        last_entry.anomaly = anomaly;
        mutex_unlock(&ai_sched_lock);
        pr_info("AI-SCHED: pid=%d score=%d anomaly=%d\n", pid, score, anomaly);
    }
    rcu_read_unlock();

    return count;
}

static ssize_t ai_sched_read(struct file *file, char __user *buffer,
                             size_t count, loff_t *pos)
{
    char kbuf[MAX_BUF];
    int len;

    if (*pos > 0)
        return 0;

    mutex_lock(&ai_sched_lock);
    len = snprintf(kbuf, MAX_BUF, "pid=%d score=%d anomaly=%d\n",
                   last_entry.pid, last_entry.score, last_entry.anomaly);
    mutex_unlock(&ai_sched_lock);

    if (copy_to_user(buffer, kbuf, len))
        return -EFAULT;

    *pos = len;
    return len;
}

static const struct proc_ops ai_sched_proc_ops = {
    .proc_read = ai_sched_read,
    .proc_write = ai_sched_write,
};

static int __init ai_sched_init(void)
{
    proc_create(PROC_NAME, 0666, NULL, &ai_sched_proc_ops);
    pr_info("AI-SCHED module loaded: /proc/%s created\n", PROC_NAME);
    return 0;
}

static void __exit ai_sched_exit(void)
{
    remove_proc_entry(PROC_NAME, NULL);
    pr_info("AI-SCHED module unloaded\n");
}

module_init(ai_sched_init);
module_exit(ai_sched_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Research Prototype");
MODULE_DESCRIPTION("AI score interface for DQN-LSTM Linux scheduling prototype");
