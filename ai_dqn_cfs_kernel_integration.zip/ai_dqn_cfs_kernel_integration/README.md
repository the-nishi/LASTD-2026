# AI-Guided Linux Kernel Scheduling Prototype

This package provides a research prototype skeleton for kernel-level AI scheduling integration.
It does **not** replace the Linux CFS scheduler by itself. It provides:

1. A Linux kernel module exposing `/proc/ai_scheduler_score`.
2. A user-space Python daemon that writes DQN/LSTM-style scores to the kernel interface.
3. A conceptual CFS patch skeleton showing where AI-guided scheduling logic can be inserted.

## Safety
Test only inside an Ubuntu VM. Do not test first on a main laptop/desktop installation.

## Build Kernel Module

```bash
cd kernel_module
make
sudo insmod ai_sched_score.ko
cat /proc/ai_scheduler_score
```

## Run User-Space AI Controller

```bash
cd userspace
sudo python3 ai_scheduler_daemon.py
```

## Check Kernel Logs

```bash
sudo dmesg | tail -n 30
```

## Remove Module

```bash
sudo rmmod ai_sched_score
```

## Academic Use Wording

Safe wording:

> A prototype kernel-level communication interface was developed using a Linux kernel module and a `/proc` interface to pass AI-generated scheduling and anomaly scores from the user-space DQN-LSTM controller to the Linux runtime layer.

Do **not** claim full CFS replacement unless you actually modify `kernel/sched/fair.c`, compile the kernel, boot into it, and collect results.
