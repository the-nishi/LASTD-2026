#!/usr/bin/env python3
"""
User-space DQN/LSTM controller prototype.
Reads process statistics from /proc and writes AI scores to /proc/ai_scheduler_score.
This version uses heuristic scores as placeholders for a trained DQN/LSTM model.
"""

import os
import time
import random
from pathlib import Path

PROC_IFACE = Path('/proc/ai_scheduler_score')


def list_pids(limit=25):
    pids = []
    for name in os.listdir('/proc'):
        if name.isdigit():
            pids.append(int(name))
    return pids[:limit]


def compute_ai_score(pid: int):
    # Placeholder: replace with DQN scheduler score + LSTM anomaly score.
    # score: higher means scheduling preference; anomaly: higher means suspicious.
    score = random.randint(20, 95)
    anomaly = random.randint(0, 100)
    return score, anomaly


def main():
    if not PROC_IFACE.exists():
        raise SystemExit('Kernel module not loaded. Run: sudo insmod ai_sched_score.ko')

    while True:
        for pid in list_pids():
            score, anomaly = compute_ai_score(pid)
            try:
                PROC_IFACE.write_text(f'{pid} {score} {anomaly}\n')
            except PermissionError:
                raise SystemExit('Permission denied. Run with sudo.')
            except ProcessLookupError:
                continue
        time.sleep(1)


if __name__ == '__main__':
    main()
