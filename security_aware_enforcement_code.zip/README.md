# Security-Aware Enforcement Figure Generator

This ZIP contains Python code that generates a terminal-style figure similar to:

**Fig. 5. Security-aware enforcement using Linux process-control utilities**

## Files

- `generate_security_enforcement_figure.py` — main Python script
- `requirements.txt` — required Python package
- `sample_output.png` — generated sample figure

## How to Run

```bash
pip install -r requirements.txt
python generate_security_enforcement_figure.py
```

The output image will be:

```text
security_aware_enforcement_fig5.png
```

## Customization

You can edit the script to change:

- username
- process ID
- CPU usage
- command output
- figure caption
