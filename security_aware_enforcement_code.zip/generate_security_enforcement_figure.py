#!/usr/bin/env python3
"""
Generate a terminal-style figure for:
Fig. 5. Security-aware enforcement using Linux process-control utilities

Requirements:
    pip install pillow

Run:
    python generate_security_enforcement_figure.py

Output:
    security_aware_enforcement_fig5.png
"""

from PIL import Image, ImageDraw, ImageFont

W, H = 1400, 900
img = Image.new("RGB", (W, H), "white")
draw = ImageDraw.Draw(img)

def load_font(size=28, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
    ]
    for p in candidates:
        try:
            return ImageFont.truetype(p, size)
        except Exception:
            pass
    return ImageFont.load_default()

mono = load_font(30)
mono_small = load_font(24)
mono_bold = load_font(30, True)
caption_font = load_font(40)

# ---------- Terminal window ----------
x0, y0 = 35, 10
tw, th = 1330, 690
draw.rounded_rectangle([x0, y0, x0+tw, y0+th], radius=8, fill=(32, 13, 27), outline=(55,55,60))

# Header bar
header_h = 68
draw.rectangle([x0, y0, x0+tw, y0+header_h], fill=(27, 27, 30))
draw.text((x0+490, y0+18), "jannatul ferdous nishi: ~", font=mono_small, fill=(245,245,245))
draw.text((x0+25, y0+17), "⌘", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-300, y0+17), "⌕", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-230, y0+17), "≡", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-160, y0+17), "–", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-100, y0+17), "□", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-45, y0+17), "×", font=mono_small, fill=(220,220,220))

green = (90, 210, 60)
white = (235, 235, 235)
blue = (120, 180, 255)

left = x0 + 22
top = y0 + 95
line_h = 43

def prompt(y, cmd):
    draw.text((left, y), "jannatul ferdous nishi:", font=mono_bold, fill=green)
    draw.text((left+410, y), "~$", font=mono_bold, fill=blue)
    draw.text((left+455, y), cmd, font=mono, fill=white)

def text(y, s, x=None, fill=white, font=None):
    draw.text((left if x is None else x, y), s, font=font or mono, fill=fill)

y = top
prompt(y, "ps -o pid,ni,psr,pcpu,comm -p 4182")
y += line_h
text(y, "   PID    NI    PSR    %CPU    COMMAND")
y += line_h
text(y, "  4182     0      2     96.1    stress-ng")
y += line_h + 10

prompt(y, "renice +10 -p 4182")
y += line_h
text(y, "4182 (process ID) old priority 0, new priority 10")
y += line_h + 10

prompt(y, "taskset -cp 0 4182")
y += line_h
text(y, "pid 4182's current affinity mask: f")
y += line_h
text(y, "pid 4182's new affinity mask: 1")
y += line_h + 10

prompt(y, "kill -SIGSTOP 4182")
y += line_h

prompt(y, "ps -o pid,ni,psr,pcpu,stat,comm -p 4182")
y += line_h
text(y, "   PID    NI    PSR    %CPU    STAT      COMMAND")
y += line_h
text(y, "  4182    10      0      0.0    T         stress-ng")
y += line_h + 25

prompt(y, "")
draw.rectangle([left+455, y+2, left+475, y+35], fill=white)

# subtle terminal shadow / vignette
for i in range(12):
    draw.rectangle([x0+i, y0+i, x0+tw-i, y0+th-i], outline=(30+i, 20+i, 30+i))

# Caption
cap_y = 770
draw.text((35, cap_y), "Fig. 5.   Security-aware enforcement using Linux process-control", font=caption_font, fill=(0,0,0))
draw.text((35, cap_y+60), "utilities", font=caption_font, fill=(0,0,0))

img.save("security_aware_enforcement_fig5.png")
print("Saved: security_aware_enforcement_fig5.png")
