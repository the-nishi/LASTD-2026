#!/usr/bin/env python3
"""
Generate an Ubuntu-style runtime monitoring figure similar to:
Fig. 4. Ubuntu runtime monitoring during adaptive scheduling

Requirements:
    pip install pillow

Run:
    python generate_runtime_monitoring_figure.py
"""

from PIL import Image, ImageDraw, ImageFont

W, H = 1400, 500
img = Image.new("RGB", (W, H), "white")
draw = ImageDraw.Draw(img)

def load_font(size=18, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
    ]
    for p in candidates:
        try:
            return ImageFont.truetype(p, size)
        except Exception:
            pass
    return ImageFont.load_default()

mono = load_font(17)
mono_small = load_font(15)
mono_bold = load_font(17, bold=True)
caption_font = load_font(34)

x0, y0 = 20, 20
term_w, term_h = 1360, 390
title_h = 36
dock_w = 72
content_x = x0 + dock_w

draw.rounded_rectangle([x0, y0, x0+term_w, y0+term_h], radius=8, fill=(18,18,20), outline=(40,40,45))
draw.rectangle([x0, y0, x0+term_w, y0+title_h], fill=(10,10,11))
draw.text((x0+18, y0+8), "Activities", font=mono_small, fill=(245,245,245))
draw.text((x0+120, y0+8), "[ ] htop", font=mono_small, fill=(245,245,245))
draw.text((x0+term_w//2-45, y0+8), "May 14 16:42", font=mono_small, fill=(245,245,245))
draw.text((x0+term_w-115, y0+8), "*  <)  []  x", font=mono_small, fill=(245,245,245))

draw.rectangle([x0, y0+title_h, x0+dock_w, y0+term_h], fill=(34,16,38))
icons = ["Fx", "[]", "A", ">_", "~", "::"]
iy = y0 + title_h + 34
for i, ic in enumerate(icons):
    cyi = iy + i*56
    draw.rounded_rectangle([x0+18, cyi-18, x0+54, cyi+18], radius=6, fill=(82,82,84))
    draw.text((x0+27, cyi-10), ic, font=mono_small, fill=(255,255,255))

tw_x, tw_y = content_x+10, y0+55
tw_w, tw_h = term_w-dock_w-25, term_h-70
draw.rounded_rectangle([tw_x, tw_y, tw_x+tw_w, tw_y+tw_h], radius=8, fill=(12,14,16), outline=(42,42,46))
draw.rectangle([tw_x, tw_y, tw_x+tw_w, tw_y+34], fill=(25,25,27))
draw.text((tw_x+tw_w//2-120, tw_y+9), "jannatul ferdous nishi: ~", font=mono_small, fill=(245,245,245))
draw.text((tw_x+tw_w-140, tw_y+9), "search  menu  -  []  x", font=mono_small, fill=(245,245,245))

cx, cy = tw_x+25, tw_y+52

def cpu_bar(y, label, pct):
    draw.text((cx, y), label, font=mono, fill=(75,210,240))
    bx = cx + 28
    for i in range(40):
        if i < int(pct/2.5):
            if i < 26:
                col = (115,220,80)
            elif i < 34:
                col = (235,190,60)
            else:
                col = (255,80,60)
        else:
            col = (45,45,45)
        draw.text((bx+i*8, y), "|", font=mono, fill=col)
    draw.text((cx+510, y), f"{pct:>5.1f}%", font=mono, fill=(230,230,230))

cpu_bar(cy, "0", 78.1)
cpu_bar(cy+22, "1", 80.2)
cpu_bar(cy+44, "2", 68.6)

draw.text((cx, cy+72), "Mem", font=mono, fill=(75,210,240))
for i in range(40):
    col = (115,220,80) if i < 28 else ((235,190,60) if i < 35 else (245,80,90))
    draw.text((cx+38+i*8, cy+72), "|", font=mono, fill=col)
draw.text((cx+430, cy+72), "2.15G/7.68G", font=mono, fill=(230,230,230))

draw.text((cx, cy+94), "Swp", font=mono, fill=(75,210,240))
for i in range(10):
    draw.text((cx+38+i*8, cy+94), "|", font=mono, fill=(245,80,90))
draw.text((cx+430, cy+94), "512M/2.00G", font=mono, fill=(230,230,230))

rx = cx + 580
info = [("Tasks:", "156, 473 thr, 2 running"), ("Load average:", "2.35 1.89 1.32"), ("Uptime:", "00:24:31")]
for i, (k, v) in enumerate(info):
    draw.text((rx, cy+i*24), k, font=mono, fill=(50,210,210))
    draw.text((rx+150, cy+i*24), v, font=mono, fill=(95,235,120))

table_y = cy + 125
draw.rectangle([tw_x+8, table_y-4, tw_x+tw_w-8, table_y+22], fill=(95,150,50))
headers = "PID USER      PRI  NI  VIRT   RES   SHR S  CPU% MEM%    TIME+  Command"
draw.text((tw_x+20, table_y), headers, font=mono_bold, fill=(0,0,0))

rows = [
    ("4182", "jannatul", "20", "0", "2412M", "312M", "73920", "R", "95.3", "3.9", "2:15.22", "stress-ng --cpu 4 --io 2 --vm 2 --vm-bytes 512M --timeout 600s"),
    ("4251", "jannatul", "20", "0", "15232", "4680", "3632", "R", "12.6", "0.6", "0:05.44", "htop"),
    ("1", "root", "20", "0", "169M", "11264", "8428", "S", "0.0", "0.1", "0:02.35", "/sbin/init splash"),
    ("283", "root", "-20", "0", "51428", "12064", "10116", "S", "0.0", "0.2", "0:01.12", "/lib/systemd/systemd-journald"),
    ("431", "systemd-t", "20", "0", "90188", "5936", "5120", "S", "0.0", "0.1", "0:00.45", "/lib/systemd/systemd-timesyncd"),
    ("512", "root", "20", "0", "242M", "5140", "3452", "S", "0.0", "0.1", "0:00.28", "/usr/sbin/irqbalance --foreground"),
    ("658", "root", "20", "0", "255M", "11932", "7288", "S", "0.0", "0.2", "0:00.22", "/usr/libexec/bluetooth/bluetoothd"),
    ("721", "jannatul", "20", "0", "350M", "38028", "28048", "S", "0.0", "0.5", "0:01.19", "/usr/bin/gnome-shell"),
]
for idx, r in enumerate(rows):
    y = table_y + 26 + idx*24
    if idx == 0:
        draw.rectangle([tw_x+8, y-2, tw_x+tw_w-8, y+21], fill=(80,190,185))
        fill = (0,0,0)
    else:
        fill = (220,220,220)
    line = f"{r[0]:<5} {r[1]:<9} {r[2]:>3} {r[3]:>3} {r[4]:>6} {r[5]:>5} {r[6]:>6} {r[7]:>1} {r[8]:>5} {r[9]:>4} {r[10]:>9}  {r[11]}"
    draw.text((tw_x+20, y), line, font=mono, fill=fill)

menu_y = tw_y + tw_h - 24
draw.rectangle([tw_x+8, menu_y-2, tw_x+tw_w-8, menu_y+22], fill=(110,210,210))
menu = "F1Help  F2Setup  F3Search  F4Filter  F5Tree  F6SortBy  F7Nice -  F8Nice +  F9Kill  F10Quit"
draw.text((tw_x+16, menu_y), menu, font=mono_bold, fill=(0,0,0))

caption = "Fig. 4.  Ubuntu runtime monitoring during adaptive scheduling"
draw.text((65, 430), caption, font=caption_font, fill=(0,0,0))

img.save("ubuntu_runtime_monitoring_fig4.png")
print("Saved: ubuntu_runtime_monitoring_fig4.png")
