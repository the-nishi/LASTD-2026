# Ubuntu Runtime Monitoring Figure Generator

This ZIP contains Python code that generates an Ubuntu-style runtime monitoring figure similar to the paper output:

**Fig. 4. Ubuntu runtime monitoring during adaptive scheduling**

## Files

- `generate_runtime_monitoring_figure.py` — main script
- `requirements.txt` — required package
- `sample_output.png` — generated sample image

## How to Run

```bash
pip install -r requirements.txt
python generate_runtime_monitoring_figure.py
```

Output:

```text
ubuntu_runtime_monitoring_fig4.png
```
