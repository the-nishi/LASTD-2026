// ai_cfs_module.c
// Linux Kernel Module prototype for AI-CFS DQN scheduler score interface.
// Creates:
//   /proc/ai_scheduler_score
//   /proc/ai_scheduler_metrics
//
// Build with: make
// Load with : sudo insmod ai_cfs_module.ko
// Test with : echo "4182 87 THROTTLE" | sudo tee /proc/ai_scheduler_score
// Read with : cat /proc/ai_scheduler_score

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/timekeeping.h>

#define PROC_SCORE_NAME   "ai_scheduler_score"
#define PROC_METRICS_NAME "ai_scheduler_metrics"
#define BUF_SIZE 256

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jannatul Ferdous Nishi");
MODULE_DESCRIPTION("AI-CFS DQN Scheduler Score Kernel Module Prototype");
MODULE_VERSION("1.0");

static struct proc_dir_entry *score_entry;
static struct proc_dir_entry *metrics_entry;

static DEFINE_MUTEX(ai_cfs_lock);

static int last_pid = -1;
static int last_score = 0;
static char last_action[32] = "NONE";
static unsigned long total_updates = 0;
static unsigned long threat_updates = 0;
static unsigned long throttle_count = 0;
static unsigned long restrict_count = 0;
static unsigned long isolate_count = 0;

static const char *decision_from_score(int score)
{
    if (score >= 90)
        return "ISOLATE";
    if (score >= 75)
        return "RESTRICT";
    if (score >= 60)
        return "THROTTLE";
    return "NORMAL";
}

static ssize_t score_read(struct file *file, char __user *ubuf, size_t count, loff_t *ppos)
{
    char buf[BUF_SIZE];
    int len;

    if (*ppos > 0)
        return 0;

    mutex_lock(&ai_cfs_lock);
    len = snprintf(buf, BUF_SIZE,
        "PID: %d\n"
        "AI_SCORE: %d\n"
        "ACTION: %s\n"
        "DECISION_RULE: score>=90 ISOLATE, score>=75 RESTRICT, score>=60 THROTTLE, else NORMAL\n",
        last_pid, last_score, last_action);
    mutex_unlock(&ai_cfs_lock);

    if (copy_to_user(ubuf, buf, len))
        return -EFAULT;

    *ppos = len;
    return len;
}

static ssize_t score_write(struct file *file, const char __user *ubuf, size_t count, loff_t *ppos)
{
    char buf[BUF_SIZE];
    int pid, score;
    char action[32] = {0};

    if (count >= BUF_SIZE)
        return -EINVAL;

    if (copy_from_user(buf, ubuf, count))
        return -EFAULT;

    buf[count] = '\0';

    /*
     * Accepted formats:
     *   echo "4182 87" > /proc/ai_scheduler_score
     *   echo "4182 87 THROTTLE" > /proc/ai_scheduler_score
     */
    if (sscanf(buf, "%d %d %31s", &pid, &score, action) < 2)
        return -EINVAL;

    if (score < 0 || score > 100)
        return -EINVAL;

    mutex_lock(&ai_cfs_lock);

    last_pid = pid;
    last_score = score;

    if (action[0] == '\0')
        snprintf(last_action, sizeof(last_action), "%s", decision_from_score(score));
    else
        snprintf(last_action, sizeof(last_action), "%s", action);

    total_updates++;

    if (score >= 60) {
        threat_updates++;
        if (score >= 90)
            isolate_count++;
        else if (score >= 75)
            restrict_count++;
        else
            throttle_count++;
    }

    mutex_unlock(&ai_cfs_lock);

    pr_info("ai_cfs: pid=%d score=%d action=%s\n", pid, score, last_action);

    return count;
}

static ssize_t metrics_read(struct file *file, char __user *ubuf, size_t count, loff_t *ppos)
{
    char buf[BUF_SIZE];
    int len;

    if (*ppos > 0)
        return 0;

    mutex_lock(&ai_cfs_lock);
    len = snprintf(buf, BUF_SIZE,
        "AI-CFS Kernel Module Metrics\n"
        "Status: ACTIVE\n"
        "Total Score Updates: %lu\n"
        "Threat Updates: %lu\n"
        "Throttle Count: %lu\n"
        "Restrict Count: %lu\n"
        "Isolate Count: %lu\n",
        total_updates, threat_updates, throttle_count, restrict_count, isolate_count);
    mutex_unlock(&ai_cfs_lock);

    if (copy_to_user(ubuf, buf, len))
        return -EFAULT;

    *ppos = len;
    return len;
}

static const struct proc_ops score_ops = {
    .proc_read = score_read,
    .proc_write = score_write,
};

static const struct proc_ops metrics_ops = {
    .proc_read = metrics_read,
};

static int __init ai_cfs_init(void)
{
    score_entry = proc_create(PROC_SCORE_NAME, 0666, NULL, &score_ops);
    if (!score_entry) {
        pr_err("ai_cfs: failed to create /proc/%s\n", PROC_SCORE_NAME);
        return -ENOMEM;
    }

    metrics_entry = proc_create(PROC_METRICS_NAME, 0444, NULL, &metrics_ops);
    if (!metrics_entry) {
        proc_remove(score_entry);
        pr_err("ai_cfs: failed to create /proc/%s\n", PROC_METRICS_NAME);
        return -ENOMEM;
    }

    pr_info("ai_cfs: AI-CFS DQN scheduler score module loaded\n");
    return 0;
}

static void __exit ai_cfs_exit(void)
{
    proc_remove(score_entry);
    proc_remove(metrics_entry);
    pr_info("ai_cfs: module unloaded\n");
}

module_init(ai_cfs_init);
module_exit(ai_cfs_exit);
