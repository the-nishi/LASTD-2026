#!/bin/bash
set -e

echo "[1] Build module"
make

echo "[2] Insert module"
sudo insmod ai_cfs_module.ko || true

echo "[3] Send AI score"
echo "4182 87 RESTRICT" | sudo tee /proc/ai_scheduler_score

echo "[4] Read AI score"
cat /proc/ai_scheduler_score

echo "[5] Read metrics"
cat /proc/ai_scheduler_metrics

echo "[6] Kernel logs"
dmesg | grep ai_cfs | tail -n 10
