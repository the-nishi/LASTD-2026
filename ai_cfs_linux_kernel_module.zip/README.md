# AI-CFS Linux Kernel Module Prototype

This package provides a **Linux Kernel Module prototype** for an AI-guided scheduler interface.  
It does **not fully replace Linux CFS**, but it creates a kernel-level `/proc` interface where a user-space DQN model can send process risk/scheduling scores.

## Files

- `ai_cfs_module.c` — Linux kernel module source code
- `Makefile` — build file
- `ai_score_writer.py` — user-space demo script to send AI scores
- `test_commands.sh` — build/load/test commands

## Install Dependencies

```bash
sudo apt update
sudo apt install build-essential linux-headers-$(uname -r) python3
```

## Build

```bash
make
```

## Load Module

```bash
sudo insmod ai_cfs_module.ko
```

## Test

```bash
echo "4182 87 RESTRICT" | sudo tee /proc/ai_scheduler_score
cat /proc/ai_scheduler_score
cat /proc/ai_scheduler_metrics
dmesg | grep ai_cfs | tail
```

## Run User-Space AI Score Writer

```bash
sudo python3 ai_score_writer.py
```

## Remove Module

```bash
sudo rmmod ai_cfs_module
make clean
```

## Expected Output

```text
PID: 4182
AI_SCORE: 87
ACTION: RESTRICT
```

Kernel log:

```text
ai_cfs: AI-CFS DQN scheduler score module loaded
ai_cfs: pid=4182 score=87 action=RESTRICT
```

## Academic Use Warning

This is a **kernel-level communication prototype**.  
For a journal paper, do not claim full Linux CFS modification unless you actually patch `kernel/sched/fair.c`, compile a custom kernel, boot it, and collect real benchmark evidence.
