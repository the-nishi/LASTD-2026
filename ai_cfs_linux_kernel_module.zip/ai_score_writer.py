#!/usr/bin/env python3
"""
User-space DQN score writer demo.
This simulates DQN-generated AI scores and sends them to the kernel module through /proc/ai_scheduler_score.
"""

import os
import random
import subprocess
import time

PROC_PATH = "/proc/ai_scheduler_score"

def get_top_processes(limit=5):
    cmd = ["ps", "-eo", "pid,pcpu,comm", "--sort=-pcpu"]
    out = subprocess.check_output(cmd, text=True).strip().splitlines()[1:limit+1]
    result = []
    for line in out:
        parts = line.split(None, 2)
        if len(parts) == 3:
            pid, cpu, comm = parts
            result.append((int(pid), float(cpu), comm))
    return result

def score_process(cpu):
    # Demo scoring rule. Replace this with real DQN inference.
    if cpu >= 80:
        return random.randint(90, 99)
    if cpu >= 60:
        return random.randint(75, 89)
    if cpu >= 35:
        return random.randint(60, 74)
    return random.randint(5, 40)

def action_from_score(score):
    if score >= 90:
        return "ISOLATE"
    if score >= 75:
        return "RESTRICT"
    if score >= 60:
        return "THROTTLE"
    return "NORMAL"

def main():
    if not os.path.exists(PROC_PATH):
        raise SystemExit(f"{PROC_PATH} not found. Load kernel module first: sudo insmod ai_cfs_module.ko")

    while True:
        for pid, cpu, comm in get_top_processes():
            score = score_process(cpu)
            action = action_from_score(score)
            payload = f"{pid} {score} {action}\n"
            with open(PROC_PATH, "w", encoding="utf-8") as f:
                f.write(payload)
            print(f"sent: pid={pid} cpu={cpu:.1f}% score={score} action={action} comm={comm}")
        time.sleep(3)

if __name__ == "__main__":
    main()
