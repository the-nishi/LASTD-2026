# Metrics Figure Generator

This ZIP contains Python code to generate three paper-ready evaluation figures:

1. **Fig. 7** — Confusion matrix of the proposed LSTM-based intelligent threat detection model  
2. **Fig. 8** — ROC curve comparison of the proposed threat detection model  
3. **Fig. 9** — Precision-Recall curve comparison on CICIDS2017 dataset  

## Files

- `generate_metrics_figures.py` — main Python script
- `requirements.txt` — required Python packages
- `sample_fig7_confusion_matrix.png`
- `sample_fig8_roc_curve.png`
- `sample_fig9_precision_recall_curve.png`

## How to Run

```bash
pip install -r requirements.txt
python generate_metrics_figures.py
```

## Outputs

```text
fig7_confusion_matrix.png
fig8_roc_curve.png
fig9_precision_recall_curve.png
```

## Notes

You can edit the script to change:
- confusion matrix values
- AUC/AP labels
- model names
- figure titles
- output filenames
