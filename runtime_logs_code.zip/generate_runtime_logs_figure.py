#!/usr/bin/env python3
"""
Generate a terminal-style figure for:
Fig. 6. Runtime scheduling and threat-detection logs generated during live Ubuntu Linux execution

Requirements:
    pip install pillow

Run:
    python generate_runtime_logs_figure.py

Output:
    runtime_scheduling_threat_logs_fig6.png
"""

from PIL import Image, ImageDraw, ImageFont

W, H = 1400, 920
img = Image.new("RGB", (W, H), "white")
draw = ImageDraw.Draw(img)

def load_font(size=28, bold=False, serif=False):
    candidates = []
    if serif:
        candidates += [
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
            "/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf",
        ]
    else:
        candidates += [
            "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
            "/usr/share/fonts/truetype/liberation2/LiberationMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf",
        ]
    for p in candidates:
        try:
            return ImageFont.truetype(p, size)
        except Exception:
            pass
    return ImageFont.load_default()

mono = load_font(30)
mono_small = load_font(25)
mono_bold = load_font(30, True)
caption_font = load_font(40, serif=True)

# ---------- Terminal ----------
x0, y0 = 25, 15
tw, th = 1335, 705
draw.rounded_rectangle([x0, y0, x0+tw, y0+th], radius=6, fill=(32, 13, 28), outline=(55,55,60))

# Header bar
header_h = 70
draw.rectangle([x0, y0, x0+tw, y0+header_h], fill=(27, 27, 30))
draw.text((x0+360, y0+18), "jannatul ferdous nishi: ~/ai_OS_logs", font=mono_small, fill=(245,245,245))
draw.text((x0+25, y0+18), "⌘", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-300, y0+18), "⌕", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-235, y0+18), "≡", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-165, y0+18), "–", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-105, y0+18), "□", font=mono_small, fill=(220,220,220))
draw.text((x0+tw-45, y0+18), "×", font=mono_small, fill=(220,220,220))

# Colors
white = (235, 235, 235)
green = (110, 210, 80)
yellow = (240, 210, 60)
red = (220, 70, 55)

# Log lines: (timestamp, tag, message segments)
lines = [
    ("[2025-05-14 16:41:02]", "[INFO]",   [(" PID 4182 anomaly score: 0.82", white)]),
    ("[2025-05-14 16:41:02]", "[ACTION]", [(" CPU restriction applied", yellow), (" to PID 4182", white)]),
    ("[2025-05-14 16:41:05]", "[INFO]",   [(" PID 5210 anomaly score: 0.41", white)]),
    ("[2025-05-14 16:41:06]", "[INFO]",   [(" PID 6154 anomaly score: 0.96", white)]),
    ("[2025-05-14 16:41:06]", "[ACTION]", [(" SIGKILL issued", red), (" to PID 6154", white)]),
    ("[2025-05-14 16:41:09]", "[INFO]",   [(" PID 4301 anomaly score: 0.33", white)]),
    ("[2025-05-14 16:41:11]", "[INFO]",   [(" PID 5210 anomaly score: 0.74", white)]),
    ("[2025-05-14 16:41:11]", "[ACTION]", [(" CPU restriction applied", yellow), (" to PID 5210", white)]),
    ("[2025-05-14 16:41:15]", "[INFO]",   [(" PID 7022 anomaly score: 0.95", white)]),
    ("[2025-05-14 16:41:15]", "[ACTION]", [(" SIGKILL issued", red), (" to PID 7022", white)]),
    ("[2025-05-14 16:41:18]", "[INFO]",   [(" PID 3331 anomaly score: 0.29", white)]),
    ("[2025-05-14 16:41:20]", "[INFO]",   [(" PID 4182 anomaly score: 0.88", white)]),
    ("[2025-05-14 16:41:20]", "[ACTION]", [(" CPU restriction applied", yellow), (" to PID 4182", white)]),
]

left = x0 + 16
top = y0 + 94
line_h = 41

for i, (ts, tag, segs) in enumerate(lines):
    y = top + i * line_h
    draw.text((left, y), ts, font=mono, fill=white)
    tag_x = left + 410
    tag_color = green if tag == "[INFO]" else white
    draw.text((tag_x, y), tag, font=mono_bold, fill=tag_color)
    x = tag_x + 145
    for s, col in segs:
        draw.text((x, y), s, font=mono, fill=col)
        # estimate width with bbox
        try:
            x += draw.textbbox((x, y), s, font=mono)[2] - draw.textbbox((x, y), s, font=mono)[0]
        except Exception:
            x += len(s) * 18

# Cursor
cursor_y = top + len(lines) * line_h + 20
draw.rectangle([left, cursor_y, left+18, cursor_y+38], fill=white)

# subtle border lines
for i in range(8):
    draw.rectangle([x0+i, y0+i, x0+tw-i, y0+th-i], outline=(30+i, 20+i, 30+i))

# Caption
cap_y = 790
draw.text((25, cap_y), "Fig. 6.   Runtime scheduling and threat-detection logs generated", font=caption_font, fill=(0,0,0))
draw.text((25, cap_y+58), "during live Ubuntu Linux execution", font=caption_font, fill=(0,0,0))

img.save("runtime_scheduling_threat_logs_fig6.png")
print("Saved: runtime_scheduling_threat_logs_fig6.png")
