# Runtime Scheduling and Threat-Detection Logs Figure Generator

This ZIP contains Python code that generates a terminal-style figure similar to:

**Fig. 6. Runtime scheduling and threat-detection logs generated during live Ubuntu Linux execution**

## Files

- `generate_runtime_logs_figure.py` — main Python script
- `requirements.txt` — required Python package
- `sample_output.png` — generated sample image

## How to Run

```bash
pip install -r requirements.txt
python generate_runtime_logs_figure.py
```

Output:

```text
runtime_scheduling_threat_logs_fig6.png
```

## Customization

You can edit the script to change:

- timestamps
- PID values
- anomaly scores
- action messages
- terminal title
- figure caption
